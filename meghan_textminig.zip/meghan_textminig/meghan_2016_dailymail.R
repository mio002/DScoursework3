library(dplyr)
library(tidytext)
library(tidyr)

dailymail <- read.csv("dailymail4.csv", header = FALSE)

# CLEANING
# rename the column headings
dailymail <-rename(dailymail, c("tweet"="V1"))

dailymail_bigrams <- dailymail %>%
  unnest_tokens(bigram, tweet, token = "ngrams", n = 2)

dailymail_bigrams_counts <- dailymail_bigrams %>% 
  count(bigram, sort = TRUE)

dailymail_bigrams_separated <- dailymail_bigrams %>%
  separate(bigram, c("word1", "word2"), sep = " ")

dailymail_filtered <- dailymail_bigrams_separated %>%
  filter(!word1 %in% stop_words$word) %>%
  filter(!word2 %in% stop_words$word) 

# new bigram counts:
dailymail_counts <- dailymail_filtered %>% 
  count(word1, word2, sort = TRUE)

write.csv(dailymail_counts,'dailymail_counts_2016.csv')
