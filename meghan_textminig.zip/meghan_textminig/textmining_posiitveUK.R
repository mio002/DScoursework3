# EXERCISE 1 - Word frequency and wordcloud
library(lubridate)
library(dplyr)
library(tm)
library(wordcloud)
library(ggplot2)

# LOAD
# read in some tweets and dates
positive_singleUK_cloud <- read.csv("meghan_2016_positive_singleUK.csv", header = FALSE)
# CLEAN
# rename the column headings as there were none in the file
positive_singleUK_cloud <-rename(positive_singleUK_cloud, c("tweet"="V2", "usernema"="V1"))
# use lubridate to sort the dates out
# because class(tweets_df$date) says character type
tweets_df$date <- ymd_hms(tweets_df$date)
# because the tweets are in the right format now we can do this
hist(tweets_df$date, "weeks", freq =TRUE)
# see https://astrostatistics.psu.edu/su07/R/html/graphics/html/hist.POSIXt.html

# FILTER
# dyplr cheatsheet https://rstudio.com/wp-content/uploads/2015/02/data-wrangling-cheatsheet.pdf
# and https://stackoverflow.com/questions/22850026/filter-rows-which-contain-a-certain-string
original_tweets <- tweets_df %>%
  filter(!grepl('RT @',tweets_df$tweet))

# PROCESS
# lets see what words are there using tm (text mining) package
# http://www.sthda.com/english/wiki/text-mining-and-word-cloud-fundamentals-in-r-5-simple-steps-you-should-know
# I had to add this line to the guide above as the Corpus method is happier with a data frame with specific column names as a source
# https://stackoverflow.com/questions/47406555/error-faced-while-using-tm-packages-vcorpus-in-r
df <- data.frame(doc_id=row.names(positive_singleUK_cloud),
                 text=positive_singleUK_cloud$tweet)
# tur the dataframe into a Corpus
doc <- Corpus(DataframeSource(df))
# clean the data up
doc <- tm_map(doc, content_transformer(tolower))
doc <- tm_map(doc, removeWords, stopwords("english"))
doc <- tm_map(doc, removePunctuation)
doc <- tm_map(doc, stripWhitespace)
doc <- tm_map(doc, removeWords, c("amp")) # amp is from URL encoding
# now calculate the word frequencies and put them in a matrix 
# these two steps can take up a lot of memory and time if you have LOTS of text
dtm <- TermDocumentMatrix(doc)
m <- as.matrix(dtm)
# sort the matrix by frequency
v <- sort(rowSums(m),decreasing=TRUE)
# put the results into a dataframe so we can use it easily
d <- data.frame(word = names(v),freq=v)

# ANALYSE
# take a look at the first 10
head(d, 20)

# plot a frequency chart
barplot(d[1:20,]$freq, las = 2, names.arg = d[1:20,]$word,
        col ="lightblue", main ="Most frequent words",
        ylab = "Word frequencies")

# and basic wordclooud
set.seed(1234)
wordcloud(words = d$word, freq = d$freq, min.freq = 1,
          max.words=100, random.order=FALSE, 
          colors=brewer.pal(8, "Dark2"))

# Find associations with the top three, you play with the correlation limit to get more or less
# strongly corrlated terms, set it to high and you will get none
findAssocs(dtm, terms = c("will","great","people"), corlimit = 0.1)
# Find associations with other stuff
findAssocs(dtm, terms = c("russia","france","iran"), corlimit = 0.2)



# exercise tip
# original_tweets <- original_tweets %>%
#  filter(grepl('Russia',original_tweets$tweet))
