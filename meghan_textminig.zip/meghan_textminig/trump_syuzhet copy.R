library(syuzhet)
library(dplyr)
library(lubridate)
library(ggplot2)

positive_cloud <- read.csv("meghan_2016_positive_single.csv", header = FALSE)

# CLEANING
# rename the column headings
positive_cloud <-rename(positive_cloud, c("username"="V1", "tweet"="V2"))


# use lubridate to sort the dates out
# because class(tweets_df$date) says character type
tweets_df$date <- ymd_hms(tweets_df$date)

# FILTER
original_tweets <- tweets_df %>%
  filter(!grepl('RT @',tweets_df$tweet))

# ANALYSIS

# Basic Sentiment
# now for the default method
s_v_sentiment <- get_sentiment(tweets_df$tweet)

# syhuzet produces one number for each sentence, emotional valence
# the sum and mean of the syuzhet method shows he's generally postivie
sum(s_v_sentiment)
mean(s_v_sentiment)

# the plot looks  complicated but does show some overall trends
plot(
  s_v_sentiment, 
  type="l", 
  main="Example Plot Trajectory", 
  xlab = "Narrative Time", 
  ylab= "Emotional Valence"
)

# now we can get some interesting views
# we asre divindg the tweets into chunks and then showing them
# bins is the number of chunks
percent_vals <- get_percentage_values(s_v_sentiment, bins = 100)
plot(
  percent_vals, 
  type="l", 
  main="Donald Trumps Tweets", 
  xlab = "Narrative Time", 
  ylab= "Emotional Valence", 
  col="red"
)

# NRC sentiment
# this allocates a score from 0-10 for various emotions and an overall polarity
# may take a while to run the next line!
nrc_sentiment <- get_nrc_sentiment(positive_cloud$tweet)

# once this is done we can filter the angry ones for example!
angry_items <- which(nrc_sentiment$anger > 0)


# plot a chart
# lets have  a look at the distribution
barplot(colSums(nrc_sentiment),col=rainbow(10),ylab='count',main='sentiment scores for tweets')

# if we want to see the ratings and the orginal tweet we need to bind them
tweet_sentiment <- cbind(tweets_df$tweet,nrc_sentiment)

# Freestyle - filter donalds tweets ot get someone elses
# so we can now filter down in the tweet set on tweets with the word Russia for example
russia_tweets <- original_tweets %>%
  filter(grepl('Russia',original_tweets$tweet))

russia_sentiment <- get_sentiment(russia_tweets$tweet)

sum(russia_sentiment)
mean(russia_sentiment)

russia_percent_vals <- get_percentage_values(russia_sentiment, bins = 50)


?write.table

write.table(tweet_sentiment, file = "tweet_sentiment.csv", sep = ",")



