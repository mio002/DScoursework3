library(dplyr)
library(tidytext)
library(tidyr)
library(forcats)
library(ggplot2)

UKmedia <- read.csv("UKmedia_text.csv", header = FALSE)

# CLEANING
# rename the column headings
UKmedia <-rename(UKmedia, c("tweet"="V2","media"="V1" ))

UKmedia_bigrams <- UKmedia  %>%
  unnest_tokens(bigram, tweet, token = "ngrams", n = 2)

UKmedia_counts <- UKmedia_bigrams %>% 
  count(bigram, sort = TRUE)

UKmedia_bigrams_separated <- UKmedia_bigrams %>%
  separate(bigram, c("word1", "word2"), sep = " ")

UKmedia_filtered <- UKmedia_bigrams_separated %>%
  filter(!word1 %in% stop_words$word) %>%
  filter(!word2 %in% stop_words$word) 

# new bigram counts:
UKmedia_counts <- UKmedia_filtered %>% 
  count(word1, word2, sort = TRUE)

UKmedia_united <- UKmedia_filtered %>%
  unite(bigram, word1, word2, sep = " ")

UKmedia_tf_idf <- UKmedia_united %>%
  count(media, bigram) %>%
  bind_tf_idf(bigram, media, n) %>%
  arrange(desc(tf_idf))

UKmedia_tf_idf %>%
  group_by(media) %>%
  slice_max(tf_idf, n = 15) %>%
  ungroup() %>%
  ggplot(aes(tf_idf, fct_reorder(bigram, tf_idf), fill = media)) + 
  geom_col(show.legend = FALSE) +
  facet_wrap(~media, ncol = 2, scales = "free") +
  labs(x = "tf-idf", y = NULL)

write.csv(dailymail_counts,'dailymail_counts_2016.csv')
