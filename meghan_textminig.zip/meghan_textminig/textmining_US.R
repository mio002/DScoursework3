# EXERCISE 1 - Word frequency and wordcloud
library(lubridate)
library(dplyr)
library(tm)
library(wordcloud)


# LOAD
# read in some tweets and dates
cloudUS <- read.csv("2016US.csv", header = FALSE)
# CLEAN
# rename the column headings as there were none in the file
cloudUS <-rename(cloudUS, c("tweet"="V2", "usernema"="V1"))
# use lubridate to sort the dates out
#/R/html/graphics/html/hist.POSIXt.html

# FILTER
# dyplr cheatsheet https://rstudio.com/wp-content/uploads/2015/02/data-wrangling-cheatsheet.pdf
# and https://stackoverflow.com/questions/22850026/filter-rows-which-contain-a-certain-string
original_tweets <- tweets_df %>%
  filter(!grepl('RT @',tweets_df$tweet))

# PROCESS
# lets see what words are there using tm (text mining) package
# http://www.sthda.com/english/wiki/text-mining-and-word-cloud-fundamentals-in-r-5-simple-steps-you-should-know
# I had to add this line to the guide above as the Corpus method is happier with a data frame with specific column names as a source
# https://stackoverflow.com/questions/47406555/error-faced-while-using-tm-packages-vcorpus-in-r
df <- data.frame(doc_id=row.names(cloudUS),
                 text=cloudUS$tweet)
# tur the dataframe into a Corpus
doc <- Corpus(DataframeSource(df))
# clean the data up
doc <- tm_map(doc, content_transformer(tolower))
doc <- tm_map(doc, removeWords, stopwords("english"))
doc <- tm_map(doc, removePunctuation)
doc <- tm_map(doc, stripWhitespace)
doc <- tm_map(doc, removeWords, c("amp")) # amp is from URL encoding
# now calculate the word frequencies and put them in a matrix 
# these two steps can take up a lot of memory and time if you have LOTS of text
dtm <- TermDocumentMatrix(doc)
m <- as.matrix(dtm)
# sort the matrix by frequency
v <- sort(rowSums(m),decreasing=TRUE)
# put the results into a dataframe so we can use it easily
d <- data.frame(word = names(v),freq=v)

# ANALYSE

# and basic wordclooud
set.seed(1234)
wordcloud(words = d$word, freq = d$freq, scale=c(3,.5), min.freq = 1,
          max.words=100, random.order=FALSE, 
          colors=brewer.pal(8, "Dark2"))

