library(sentimentr)
tweets_df <- read.csv("trump_tweets.csv", header = FALSE)

# CLEANING
# rename the column headings
tweets_df <-rename(tweets_df, c("tweet"="V1", "date"="V2"))

# use lubridate to sort the dates out
# because class(tweets_df$date) says character type
tweets_df$date <- ymd_hms(tweets_df$date)

# FILTER
original_tweets <- tweets_df %>%
  filter(!grepl('RT @',tweets_df$tweet))

# ANALYSIS 
sentences <- get_sentences(original_tweets$tweet)
# extracts 'elements' rather than each tweet
# see the docs https://github.com/trinker/sentimentr#preferred-workflow
sentiment(sentences)

# should be more accurate if there are tweets with more than one sentence
# not that this seems to be the case with Trumps tweets, but eiother way the output
# is cleanmer as it doesn't bother with sentence_id
sentiment_analysis <- sentiment_by(sentences)

# have a look at the output, sentimentr includes some stats in different cols
summary(sentiment_analysis)

# have a look at the average per sentence sentiment distribution
# notice that the negation handling seems made Trump a bit more negative perhaps
hist(sentiment_analysis$ave_sentiment)

# it has it's own basic plot function as well, showing syuzhet valence
# https://github.com/trinker/sentimentr#plotting-at-the-sentence-level
plot(sentiment_analysis)











