//  2017 Elin E Wibe

// JS scroll progress in article bar
window.onscroll = function() {myFunction()};

function myFunction() {
  var winScroll = document.documentElement.scrollTop;
  var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  var scrolled = (winScroll / height) * 100;
  document.getElementById("scrollBar").style.width = scrolled + "%";
}
